import {exception as displayException} from 'core/notification'; 
import Templates from 'core/templates';


export const init =() => {
    //definicion de url
const url=M.cfg.wwwroot+'/webservice/rest/server.php';
      window.console.log(url);
  
}